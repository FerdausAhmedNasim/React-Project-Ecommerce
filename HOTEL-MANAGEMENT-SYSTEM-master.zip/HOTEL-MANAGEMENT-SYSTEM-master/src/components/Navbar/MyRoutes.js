// import React from 'react'
// import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
// import Navbar from './Navbar';
// import Home from '../../screens/Home/Home';
// import About from '../../screens/About/About';
// import Contact from '../../screens/Contact/Contact';
// import Rooms from '../../screens/Rooms/Rooms';
// import Login from '../Login/Login';
// import Signup from '../Signup/Signup';


// const MyRoutes = () => {
//     return (
//         <Router>
//             <Navbar />

//             <Routes>

//                 <Route path="/" element={<Home/>}/>
//                 <Route path="/about" element={<About/>}/>
//                 <Route path="/rooms" element={<Rooms/>}/>
//                 <Route path="/contact" element={<Contact/>}/>
//                 <Route path="/login" element={<Login/>}/>
//                 <Route path="/signup" element={<Signup/>}/>


//             </Routes>
//         </Router>

//     );
// };

// export default MyRoutes
