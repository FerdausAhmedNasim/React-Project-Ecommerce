// import React from 'react'
// import { Link } from 'react-router-dom';
// import {FaRegMeh} from 'react-icons/fa';
// import MyCarousel from '../components/Carousel/MyCarousel'
// import MyFooter from '../components/Footer/MyFooter';
// import MyCopyright from '../components/Copyright/MyCopyright'

// export default function Error() {
//     return (
//         <>
//         {/* <Hero hero="roomsError" /> */}
//         <MyCarousel/>
//         {/* <Banner title="ERROR 404 NOT FOUND" subtitle="You are lost !! ITs dark everywhere">
//                 <FaRegMeh className="lost"></FaRegMeh>
//                 <Link to="/" className="btn btn-warning">
//                       RETURN HOME
//                 </Link>
//         </Banner> */}
//         <MyFooter/>
//         <MyCopyright/>
//         </>
//     )
// }
