<?php
header('Content-Type: application/json');

header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET");
include ('config.php');

// Get roomType from URL parameters
$roomType = $_GET['roomType'];

// Prepare and execute SQL query
$sql = "SELECT * FROM rooms WHERE roomtype = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $roomType);
$stmt->execute();
$result = $stmt->get_result();

// Fetch data and return as JSON
$roomDetails = $result->fetch_assoc();
echo json_encode($roomDetails);

$stmt->close();
$conn->close();
?>
