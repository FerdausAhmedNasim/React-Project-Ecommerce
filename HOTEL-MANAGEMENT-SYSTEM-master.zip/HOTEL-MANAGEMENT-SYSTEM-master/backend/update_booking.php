<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type");
header("Access-Control-Allow-Methods: POST");

// Include database configuration
include 'config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);
    if (isset($data['id']) && isset($data['status'])) {
        $id = intval($data['id']);
        $status = $data['status'];
        $query = "UPDATE bookings SET status = ? WHERE id = ?";
        if ($stmt = $conn->prepare($query)) {
            $stmt->bind_param('si', $status, $id);
            $stmt->execute();
            $stmt->close();
            echo json_encode(["success" => true]);
        } else {
            echo json_encode(["success" => false, "error" => "Failed to prepare statement"]);
        }
    } else {
        echo json_encode(["success" => false, "error" => "Invalid data"]);
    }
    $conn->close();
} else {
    echo json_encode(["success" => false, "error" => "Invalid request method"]);
}
?>
