<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type");

// Enable error reporting
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Database configuration
include('config.php');


// Import PHPMailer classes into the global namespace
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Load Composer's autoloader if you installed PHPMailer using Composer
require 'vendor/autoload.php';

// Or load PHPMailer manually if you downloaded it manually
// require 'path/to/PHPMailer/src/Exception.php';
// require 'path/to/PHPMailer/src/PHPMailer.php';
// require 'path/to/PHPMailer/src/SMTP.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $fullName = isset($_POST['full_name']) ? $_POST['full_name'] : '';
    $email = isset($_POST['email']) ? $_POST['email'] : '';
    $message = isset($_POST['message']) ? $_POST['message'] : '';

    // Validate the inputs (You can add more validation here)
    if (empty($fullName) || empty($email) || empty($message)) {
        echo 'Please fill in all required fields.';
        exit;
    }

    $mail = new PHPMailer(true);
    try {
        // Server settings
        $mail->isSMTP();                                         // Send using SMTP
        $mail->Host       = 'smtp.gmail.com';                  // Set the SMTP server to send through
        $mail->SMTPAuth   = true;                                // Enable SMTP authentication
        $mail->Username   = 'isdbbisewroundnasim@gmail.com';            // SMTP username
        $mail->Password   = 'umfflvsxxqxkdfdj';               // SMTP password
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;      // Enable TLS encryption
        $mail->Port       = 587;                                 // TCP port to connect to

        // Recipients
        $mail->setFrom('isdbbisewroundnasim@gmail.com', 'Your Name');
        $mail->addAddress('ferdausahmed2020@gmail.com', 'Recipient Name'); // Add a recipient

        // Content
        $mail->isHTML(true);                                    // Set email format to HTML
        $mail->Subject = 'New Contact Form Submission';
        $mail->Body    = "
            <h1>New Contact Message</h1>
            <p><strong>Full Name:</strong> $fullName</p>
            <p><strong>Email:</strong> $email</p>
            <p><strong>Message:</strong> $message</p>
        ";
        $mail->AltBody = "Full Name: $fullName\nEmail: $email\nMessage: $message";

        // Send email
        $mail->send();
        echo 'Message sent successfully!';
    } catch (Exception $e) {
        echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
    }
} else {
    echo 'Invalid request method.';
}


// Check if the form was submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check if the form data is set
    if (!empty($_POST['full_name']) && !empty($_POST['email']) && !empty($_POST['message'])) {
        // Retrieve and sanitize input data
        $full_name = htmlspecialchars(trim($_POST['full_name']));
        $email = htmlspecialchars(trim($_POST['email']));
        $message = htmlspecialchars(trim($_POST['message']));

        // Prepare SQL query
        $stmt = $conn->prepare("INSERT INTO contacts (full_name, email, message) VALUES (?, ?, ?)");
        if ($stmt) {
            $stmt->bind_param("sss", $full_name, $email, $message);

            // Execute query and check for success
            if ($stmt->execute()) {
                echo "Your message has been sent successfully!";
            } else {
                echo "Error executing query: " . $stmt->error;
            }

            // Close statement
            $stmt->close();
        } else {
            echo "Error preparing statement: " . $conn->error;
        }
    } else {
        echo "Form data is empty or missing.";
        var_dump($_POST); // Debugging output
    }
} else {
    echo "Invalid request method.";
}

// Close connection
$conn->close();
?>