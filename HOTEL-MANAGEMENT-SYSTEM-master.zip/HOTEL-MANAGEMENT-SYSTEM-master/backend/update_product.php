<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type");

include 'config.php';

if($_SERVER['REQUEST_METHOD'] === 'POST')
{
	$id = $_POST['id'];
	$product_name = $_POST['product_name'];
	$description = $_POST['description'];
	$price = $_POST['price'];
	$stock_amount = $_POST['stock_amount'];
	$status = $_POST['status'];

	//Handle file upload
	$image = $_POST['existing_image'];
	if(isset($_FILES['image']['name']) && $_FILES['image']['name'] != '')
	{
		$target_dir = "uploads/";
		$image = $target_dir . basename($_FILES['image']['name']);
		move_uploaded_file($_FILES['image']['tmp_name'], $image);
	}

	$query = "UPDATE products SET product_name = '$product_name',
			  description = '$description', price = '$price',
			  image = '$image', stock_amount = '$stock_amount',
			  status = '$status'
			  WHERE id = $id";

	if($conn->query($query) === TRUE)
	{
		echo json_encode(["success" => TRUE]);
	}

	else
	{
		echo json_encode(["success" => FALSE, "error" =>$conn->error]);
	}
}

else
{
	echo json_encode(["success" => FALSE, "error" =>"Invalid request method"]);
}

$conn->close();


?>